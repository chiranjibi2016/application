'use strict';

const fs = require('fs');
const angularCli = require('./../angular-cli.json');

angularCli.apps[0].scripts = [];

fs.writeFileSync('./angular-cli.json', JSON.stringify(angularCli, null, 2), 'utf8');
