() => {
  return ({
    getName: (name) => {
      if (location.search === '?dev=true') {
        window.xna = {
          appData: {
            backendLocationOrigin: 'http://localhost:3000'
          },
          getAjaxHeaders: () => ({
            Authorization: 'XNA-Access eyJlIbnhuYSIsInVuIjoibm90YXIgeG5hIn0=',
            'X-XNA-Client-ID': 'my-machine'
          })
        }
      }

      const locationOrigin = window.xna.appData.backendLocationOrigin;
      const url = `${locationOrigin}/demo/v1/hello?name=${name}`;
      const headers = Object.assign({}, {
        Accept: 'text/plain',
        'Content-Type': 'text/plain'
      }, window.xna.getAjaxHeaders());

      return window.fetch(url, { headers })
        .then((response) => {
          if (!response.ok) {
            return Promise.reject('Arghhh!')
          }
          return response.text()
        })
    }
  })
}