const CONTENT_TYPE = 'content-type';
const APPLICATION_JSON = 'application/json';
const TEXT_PLAIN = 'text/plain';

function handleFetch(response) {
  if (response.ok) {
    const contentType = response.headers.get(CONTENT_TYPE);
    if (contentType && contentType.includes(APPLICATION_JSON)) {
      return response.json();
    }
    if (contentType && contentType.includes(TEXT_PLAIN)) {
      return response.text();
    }
    return '';
  }
  return Promise.reject('fetch response not ok, did you forget to use handleError before handleFetch?');
}

export default handleFetch;
