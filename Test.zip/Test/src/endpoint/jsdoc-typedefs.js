/**
 * @typedef {Object} Person
 * @property {string} id - The id
 * @property {number} version - The version
 * @property {boolean} confidential - the confidential flag
 * @property {string} lockedBy - current lock owner
 * @property {string} data - base64 encoded encrypted person data
 * @property {string} checksum - hex encoded checksum of data field
 * @property {number} _occ - current update counter
 */

/**
 * @typedef {Object} SearchOptions
 * @property {number} [page=0]
 * @property {number} [size=200]
 * @property {number} [type] - restrict search to 'NATURAL' or 'ARTIFICIAL' persons
 */
