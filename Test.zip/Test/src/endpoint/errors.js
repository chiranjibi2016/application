const UNHANDLED_ERROR = 'Unhandled error';

export default {
  unhandledError: UNHANDLED_ERROR
};
