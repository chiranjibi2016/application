const CALL_ID = 'x-xna-call-id';
const X_XNA_STATUS = 'x-xna-status';

const xnaHeaders = {
  callId: CALL_ID,
  status: X_XNA_STATUS
};

export default xnaHeaders;
