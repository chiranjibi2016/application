import xnaHeaders from './xna-headers';
import errors from './errors';

/**
 * Note that fetch does not return a rejected promise in case of non-ok server responses!
 * Hence handling it here.
 * @private
 * @param response
 * @return {*}
 */
function handleErrors(response) {
  if (!response.ok) {
    const error = {
      source: location.href,
      url: response.url,
      status: response.status,
      xnaCallId: response.headers.get(xnaHeaders.callId),
      xnaStatusHeader: response.headers.get(xnaHeaders.status) || errors.unhandledError
    };

    if (window.xna && window.xna.electronIpcRenderer && window.xna.electronIpcRenderer.sendToHost) {
      window.xna.electronIpcRenderer.sendToHost('log', {
        message: error,
        logLevel: 'warn'
      });
    } else {
      console.warn('window.xna.electronIpcRenderer.sendToHost method unavailable, cannot log error!'); // eslint-disable-line
      console.warn(error); // eslint-disable-line
    }

    return Promise.reject(error);
  }
  return response;
}

export default handleErrors;
