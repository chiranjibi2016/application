// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
    // attribute to specify that the file is used for production.
    production:true,
  
    restBaseUrl: '../',
  
    // endpoint URL to all AoC.
    getAllAoCURL: '/amountOfCustodies',
    // endpoint URL to create an AoC.
    // id = default 0
    createAoCURL: '/amountOfCustodies/{id}',
    // endpoint URL to update an AoC.
    // id = aoc id
    updateAoCURL: '/amountOfCustodies/{id}',
    // endpoint URL to get current looged in user details.
    currentUser: '/currentUser'
  };