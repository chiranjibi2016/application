const USER_ID = 'nxna';
const ORGANIZATION_ID = '862cd5f7-01ca-4678-b4f0-231eef1b765c';

window.xna = {
  resources: [
    {
      "type": "page",
      "sortPriority": 100,
      "tabs": "multi",
      "role": [
        "resourcePanelListable",
        "requirePermissionToManagePersons",
        "createNaturalPersonEntrypoint"
      ],
      "label": "Neue natürliche Person",
      "url": "index.html#/persons-create/natural-person",
      "iconUrl": "persons.svg"
    },
    {
      "type": "page",
      "sortPriority": 50,
      "tabs": "multi",
      "role": [
        "resourcePanelListable",
        "requirePermissionToManagePersons",
        "createNonNaturalPersonEntrypoint"
      ],
      "label": "Neue nicht-natürliche Person",
      "url": "index.html#/persons-create/non-natural-person",
      "iconUrl": "persons.svg"
    },
    {
      "type": "page",
      "tabs": "multi",
      "role": [
        "requirePermissionToManagePersons",
        "editPersonEntrypoint"
      ],
      "label": "Nicht-natürliche Person bearbeiten",
      "url": "index.html#/persons-manage",
      "iconUrl": "persons.svg"
    },
    {
      "type": "page",
      "tabs": "multi",
      "role": [
        "requirePermissionToManagePersons",
        "personsOverviewEntrypoint"
      ],
      "label": "Nicht-natürliche Person Gesamtüberblick",
      "url": "index.html#/overview",
      "iconUrl": "persons.svg"
    }
  ],
  getAjaxHeaders: function () {
    return {
      "Authorization": "XNA-Access eyJlIjoiMjAxNi0xMC0wNlQxMDoyOTozOC4zMzYrMDAwMCIsIm8iOnsiaSI6Im9pZDEiLCJ0IjowfSwicnMiOlsidWJlckR1ZGUiXSwicyI6IjM0NTM0NTY0NTYiLCJ0IjoxLCJ1IjoidWlkIn0=",
      "X-XNA-Client-ID": "wpsadmins-MacBook-Pro.local"
    }
  },
  appData: {
    backendLocationOrigin: 'http://localhost:3000'
  },
  windowHelpersAdded: {
    then: (cb) => {
      cb();
    }
  },
  electronIpcRenderer: {
    sendToHost: (type, log) => {
      console.log('Logging to electron', type, log);
    },
    on: (channel, listener) => {},
    removeListener: (channel, listener) => {}
  },
  getAjaxHeaders: () => {
    return {
      Authorization: "XNA-Access eyJ1Ijoibm90YXJ4bmEiLCJlIjoiMjAxNy0wMi0wN1QxMDo0NjoyOC41MzcrMDAwMCIsInMiOiJNRVlDSVFEQ3RFVThqTkx5dWpjZDNRcC9lNWpESFNrdXdSbWhoS0tBd0FxK3A0LzhCUUloQVBTZlhNMFRUZDdha1FWaU5TYVNBWXNacUxMQUx2d1JQYVdCcUJJY2ZqK0oiLCJ0IjowLCJvIjp7ImkiOiJhYTgzYTRlYS1hZjg4LTQ3YTAtOTljNi1lOTA2YTMzN2ZkZmQiLCJ0IjoxLCJyIjoiMTg5MDciLCJycyI6WyJub3RhcnktZW1wbG95ZWUiLCJub3Rhcnktbm90YXJ5Il19fQ==",
      "X-XNA-Client-ID": "wpsadmins-MacBook-Pro.local"
    }
  },
  userData: {
    user: {
      id: USER_ID
    },
    organization: {
      id: ORGANIZATION_ID
    }
  }
};
