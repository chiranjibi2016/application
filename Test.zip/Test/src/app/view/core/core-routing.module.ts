import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AocHomeComponent } from '../aoc/aoc-home/aoc-home.component';
import { AocOverviewComponent } from '../aoc/aoc-overview/aoc-overview.component';
import { AocFormComponent } from '../aoc/aoc-form/aoc-form.component';


const routes: Routes = [
  { path: '', redirectTo: '/home/aocOverview', pathMatch: 'full' },
  // {
  //   path: 'home',
  //   component: HomeComponent,
  //   children: [
  //     { path: 'aoc', component: AocHomeComponent },
  //     { path: 'banking', component: AocHomeComponent },
  //     { path: 'booking', component: AocHomeComponent }
  //   ]
  // }
  {
    path: 'home',
    component: HomeComponent,
    children: [
      { path: 'aocOverview', component: AocOverviewComponent },
      { path: 'aocform', component: AocFormComponent },
      { path: 'banking', component: AocHomeComponent },
      { path: 'booking', component: AocHomeComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoreRoutingModule { }
