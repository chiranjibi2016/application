import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeComponent } from './home/home.component';
import { CoreRoutingModule } from './core-routing.module';
import { VvzUIModule } from '../components/vvz-ui.module';
import { AocModule } from '../aoc/aoc.module';


@NgModule({

  imports: [
    CommonModule,
    CoreRoutingModule,
    VvzUIModule,
    AocModule
  ],
  
  declarations: [
    HomeComponent
  ],

  exports: [
    HomeComponent
  ]
  
})
export class CoreModule { }
