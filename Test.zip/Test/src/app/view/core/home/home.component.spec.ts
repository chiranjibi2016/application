import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VvzHomeComponent } from './vvz-home.component';

describe('VvzHomeComponent', () => {
  let component: VvzHomeComponent;
  let fixture: ComponentFixture<VvzHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VvzHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VvzHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
