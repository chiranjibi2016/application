import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { IAocViewState } from "../../../data-store/core/model/aoc-view-state.model";
import { DevToolsExtension, NgRedux } from "@angular-redux/store";
import { IAppState, rootReducer, reimmutify } from "../../../data-store/store";
import { middleware, enhancers } from "../../../data-store/index";
import {Aoc} from "../../../data-store/aoc/model/aoc.model";
import {IViewState} from "../../../data-store/core/model/view-state.model";
import {UiLebelContants} from "../../../shared-module/constants/ui-lebel.constants";

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  moduleDetails = {
    icon: "fa-book",
    label: "Verwahrungsverzeichnis"
  }

  private _actionItems = [];

  private allAocLoadedData: any[];

  private viewState: any = {
    aoc: {
      overview: new Set(),
      [UiLebelContants.NEW_BUTTON.toLowerCase()]: new Set(),
      [UiLebelContants.EDIT.toLowerCase()]: new Set(),
      selectedAoc: new Set()
    }
  };

  private riderData = [];

  private editAocData = new Set();

  constructor(
    private _ngRedux: NgRedux<IAppState>,
    private _devToolExt: DevToolsExtension,
    private _router: Router
  ) {

    const tools = _devToolExt.enhancer({
      deserializeState: reimmutify,
    });
    _ngRedux.configureStore(
      rootReducer,
      {},
      middleware,
      tools ? [ ...enhancers, tools ] : enhancers);
  }

  ngOnInit() {
    this.viewState.aoc.overview.add({
      id: 1,
      icon: "fa-folder",
      label: "AOC Overview Table",
      state: "active",
      type: 'overview'
    });
    this.manageRiderBar('overview');
  }

  setState(item){
    this._actionItems = item.actionItems;

    if(item.hasOwnProperty('onOverviewRowClick')) {
      let selectedAoc = this.viewState.aoc.selectedAoc;
      item.onOverviewRowClick.subscribe((obj) => {
        if(obj.selected){
          selectedAoc.add(obj.data);
        } else {
          selectedAoc.delete(obj.data);
        }
      });
    }

    if(item.hasOwnProperty('dataExposed')){
      item.dataExposed.subscribe(data => {
        this.allAocLoadedData = data;
      });
    }

    if(item.hasOwnProperty('formData')) {
      item.formData = {};
    }
  }

  handleAction(evn){
    switch (evn) {
      case UiLebelContants.NEW_BUTTON.toLowerCase():
        this.onNewSelected();
      case UiLebelContants.EDIT.toLowerCase():
        this.onEditSelected();
      case UiLebelContants.SAVE.toLowerCase():
        this.editAocData.clear();
      default:
        this.manageRiderBar(evn);
    }
  }

  onNewSelected(){
    let aoc = this.viewState.aoc;

    this._router.navigate(['/home/aocform']);
    aoc.selectedAoc.clear();
    aoc[UiLebelContants.NEW_BUTTON.toLowerCase()].add(new Aoc());
    aoc.selectedAoc = new Set();
  }

  onEditSelected(){
    let check = false,
        aoc = this.viewState.aoc,
        edit = UiLebelContants.EDIT.toLowerCase();

    this._router.navigate(['/home/aocform']);

    Array.from(aoc.selectedAoc).forEach(obj => {
      for(let item of aoc[edit]){
        if(item.id === obj['id']){
          check = true;
        }
      }
      if(!check){
        aoc[edit].add(obj);
        aoc.selectedAoc = new Set();
      }
    })
  }

  manageRiderBar(type: string){
    let aoc = this.viewState.aoc,
        arr = [];
    Object.keys(aoc).forEach(k => {
      Array.from(aoc[k]).forEach((obj, i) => {
        arr.push({
          id: obj['id'],
          icon: "fa-folder",
          label: "AOC " + k.toUpperCase(),
          state: (type === k)? ((i >= (aoc[k]).size - 1)? "active" : "inactive") : 'inactive',
          objref: obj,
          type: k.toLowerCase()
        });
      })
    })
    this.riderData = arr;
  }

  onRiderRemoved(evn){
    let aoc = this.viewState.aoc;
    if(aoc.new.size >0 || aoc.edit.size >0){
      this.viewState.aoc[evn.type].delete(evn.objref);
    }
  }

  onRiderSelected(evn){
    console.log(evn.type)
    switch (evn.type) {
      case UiLebelContants.NEW_BUTTON:
        this._router.navigate(['/home/aocform'])
      case UiLebelContants.EDIT:
        this._router.navigate(['/home/aocform'])
      default:
        this._router.navigate(['/home/aocOverview'])
    }
  }
}
