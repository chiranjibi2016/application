import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VvzUIModule } from '../components/vvz-ui.module';

@NgModule({

  imports: [
    CommonModule,
    VvzUIModule
  ],

  declarations: [

  ]

})
export class BankingModule { }
