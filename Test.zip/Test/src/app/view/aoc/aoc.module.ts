import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AocHomeComponent } from './aoc-home/aoc-home.component';
import { AocFormComponent } from './aoc-form/aoc-form.component';
import { AocOverviewComponent } from './aoc-overview/aoc-overview.component';
import { VvzUIModule } from '../components/vvz-ui.module';
import { AocDetailViewComponent } from './aoc-detail-view/aoc-detail-view.component';


@NgModule({

  imports: [
    CommonModule,
    VvzUIModule,
    FormsModule,
    ReactiveFormsModule
  ],

  declarations: [
    AocHomeComponent, 
    AocFormComponent, 
    AocOverviewComponent, 
    AocDetailViewComponent
  ],

  exports: [
    AocHomeComponent, 
    AocFormComponent, 
    AocOverviewComponent,
    AocDetailViewComponent
  ],

  entryComponents: [
    AocOverviewComponent,
    AocFormComponent
  ]
  
})
export class AocModule { }
