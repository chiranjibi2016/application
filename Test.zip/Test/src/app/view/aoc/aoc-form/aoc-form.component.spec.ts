import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AocFormComponent } from './aoc-form.component';

describe('AocFormComponent', () => {
  let component: AocFormComponent;
  let fixture: ComponentFixture<AocFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AocFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AocFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
