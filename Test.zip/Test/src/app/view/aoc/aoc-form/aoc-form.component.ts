import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IAoc, Aoc } from "../../../data-store/aoc/model/aoc.model";
import { UiLebelContants } from "../../../shared-module/constants/ui-lebel.constants";
import { custody } from '../../../data-store/aoc/model/custody.model';

@Component({
  selector: 'aoc-form',
  templateUrl: './aoc-form.component.html',
  styleUrls: ['./aoc-form.component.scss']
})
export class AocFormComponent implements OnInit {

  /* Provide data for Index-Tab */
  private indexTabData = [
    {
      label: "Grunddaten",
      error: null,
      disabled: false
    },
    {
      label: "Beteiligte",
      error: null,
      disabled: false
    },
    {
      label: "Geld-/Sachverwahrungen",
      error: null,
      disabled: true
    },
    {
      label: "Buchungen",
      error: null,
      disabled: true
    },
    {
      label: "Aufträge",
      error: null,
      disabled: true
    }
  ];
  // @Input() formData: IAoc;
  @Input() formData;
  /* Provide dynamic component list */
  private componentData = [
    "Component_1", "Component_2"
  ]
  private aocFormValue: any = {};

  currentTabIndex: number = 0;
  formSubmit: boolean = false;
  formValid: boolean = false;
  isShowSearch: boolean = false;


  /* Create Form Control */
  aocForm = new FormGroup({
    'field1': new FormControl({ value: '', disabled: true }),
    'field2': new FormControl({ value: '', disabled: true }),
    'field3': new FormControl({ value: '', disabled: false }, Validators.required),
    'field4': new FormControl({ value: '', disabled: false }, Validators.required),
    'field5': new FormControl({ value: '', disabled: false }, Validators.required)
  });

  actionItems = [
    {
      icon: "fa-plus",
      label: UiLebelContants.NEW_BUTTON,
      state: false
    },
    {
      icon: "fa-pencil",
      label: UiLebelContants.EDIT,
      state: false
    },
    {
      icon: "fa-save",
      label: UiLebelContants.SAVE,
      state: true
    },
    {
      icon: "fa-save",
      label: UiLebelContants.SUBMIT,
      state: true
    }
  ]

  constructor() { }

  ngOnInit() {

    this.formData = { zuletztBearbeitet: new Date(), custody: 123456 };
    this.aocFormValue = { field1: this.formData.zuletztBearbeitet, field2: this.formData.custody }
  }

  /**
   * Tab switch function
   * @param index
   */
  onTabClick(event) {

    this.currentTabIndex = event;

    console.log('Tab ' + event + ' Clicked!!');

    if (this.currentTabIndex === 0)
      this.onFormSubmit();

    this.indexTabData[0].error = this.countError;

  }

  //Properties for accessing all FormControl objects
  get field1() {
    return this.aocForm.get('field1');
  }
  get field2() {
    return this.aocForm.get('field2');
  }
  get field3() {
    return this.aocForm.get('field3');
  }
  get field4() {
    return this.aocForm.get('field4');
  }
  get field5() {
    return this.aocForm.get('field5');
  }

  //Form Submit Function
  onFormSubmit() {
    //console.log("xx")
    this.formSubmit = true;
    this.formValid = this.aocForm.valid;
    console.log(this.aocForm.valid)
    console.log(this.aocForm.value)

    //this.aocForm.submit();

  }

  //Form total invalid fields
  get countError() {

    const controls = this.aocForm.controls;
    let count: number = null;

    for (const control in controls) {
      if (controls[control].invalid) {
        count += 1;
      }
    }
    return count;

  }

  //Add search Function
  onAddSearch() {
    this.isShowSearch = true;
  }


}
