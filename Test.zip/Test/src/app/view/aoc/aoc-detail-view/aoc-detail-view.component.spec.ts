import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AocDetailViewComponent } from './aoc-detail-view.component';

describe('AocDetailViewComponent', () => {
  let component: AocDetailViewComponent;
  let fixture: ComponentFixture<AocDetailViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AocDetailViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AocDetailViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
