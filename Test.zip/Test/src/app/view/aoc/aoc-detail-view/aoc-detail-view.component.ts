import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aoc-detail-view',
  templateUrl: './aoc-detail-view.component.html',
  styleUrls: ['./aoc-detail-view.component.css']
})
export class AocDetailViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
