import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AocHomeComponent } from './aoc-home.component';

describe('AocHomeComponent', () => {
  let component: AocHomeComponent;
  let fixture: ComponentFixture<AocHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AocHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AocHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
