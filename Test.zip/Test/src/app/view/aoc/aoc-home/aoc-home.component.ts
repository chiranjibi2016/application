import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';

@Component({
  selector: 'aoc-home',
  templateUrl: './aoc-home.component.html',
  styleUrls: ['./aoc-home.component.scss']
})

export class AocHomeComponent implements OnInit {

  //Reference of the target container.
  @ViewChild('dynamicComponentContainer', { read: ViewContainerRef }) dynamicComponentContainer: ViewContainerRef;

  constructor() {

  }

  ngOnInit() {

  }

}