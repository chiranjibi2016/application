import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AocOverviewComponent } from './aoc-overview.component';

describe('AocOverviewComponent', () => {
  let component: AocOverviewComponent;
  let fixture: ComponentFixture<AocOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AocOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AocOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
