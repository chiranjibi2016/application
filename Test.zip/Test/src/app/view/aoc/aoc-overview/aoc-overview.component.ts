import {Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import { AocActions } from '../../../abstruct-actions/aoc-actions';
import { Subject } from 'rxjs/Subject';
import {UiLebelContants} from "../../../shared-module/constants/ui-lebel.constants";


@Component({
  selector: 'aoc-overview',
  templateUrl: './aoc-overview.component.html',
  styleUrls: ['./aoc-overview.component.scss']
})
export class AocOverviewComponent implements OnInit {

  private colsmetaData: any[] = [];
  private dataTable: any[] = [];

  dataExposed: Subject<object[]> = new Subject();

  actionItems = [
    {
      icon: "fa-plus",
      label: UiLebelContants.NEW_BUTTON ,
      state: true
    },
    {
      icon: "fa-pencil",
      label: UiLebelContants.EDIT,
      state: true
    },
    {
      icon: "fa-save",
      label: UiLebelContants.SAVE,
      state: true
    },
    {
      icon: "fa-save",
      label: UiLebelContants.SUBMIT,
      state: false
    }
  ];

  onOverviewRowClick: Subject<Object[]> = new Subject();

  constructor(
    private _aocActions: AocActions
  ) { }

  ngOnInit() {
    this.loadOverviewData();
  }

  loadOverviewData(){
    this._aocActions.loadAllAocData().subscribe((data: any) => {
      this.dataTable = data;
      this.dataExposed.next(data);
      this.colsmetaData = this._aocActions.loadAocClolumnMetaData();
    });
  }

  handleRowClick(evn){
    this.onOverviewRowClick.next(Object.assign({}, evn, {data: this.dataTable[evn.index]}));
  }

  handleQuickSearch(evn){
    this.dataTable = evn;
    this.dataExposed.next(evn);
  }

}
