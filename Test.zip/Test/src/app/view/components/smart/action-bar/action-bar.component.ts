import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'action-bar',
  templateUrl: './action-bar.component.html',
  styleUrls: ['./action-bar.component.scss']
})
export class ActionBarComponent implements OnInit {

  @Input() actionItems: Array<any>;

  @Output() onAction: EventEmitter<string> = new EventEmitter<string>()

  constructor() { }

  ngOnInit() {
    console.log('ActionBarComponent -> ngOnInit()')
  }

  ngOnChange() {

  }

  handleActionClick(btn){
    this.onAction.emit(btn);
  }

}
