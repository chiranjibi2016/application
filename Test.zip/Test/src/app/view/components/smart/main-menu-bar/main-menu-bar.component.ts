import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'main-menu-bar',
  templateUrl: './main-menu-bar.component.html',
  styleUrls: ['./main-menu-bar.component.scss']
})
export class MainMenuBarComponent implements OnInit {

  menuItems = [
    {
      icon: "fa-folder",
      label: "Verwahrungsverzeichnis",
      submenus: ['Kreditinstitute', 'Buchungen', 'Aufträge']
    }
  ];

  constructor() { }

  ngOnInit() { }

}
