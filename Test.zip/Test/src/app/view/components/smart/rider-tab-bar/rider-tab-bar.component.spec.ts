import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiderTabBarComponent } from './rider-tab-bar.component';

describe('RiderTabBarComponent', () => {
  let component: RiderTabBarComponent;
  let fixture: ComponentFixture<RiderTabBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiderTabBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiderTabBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
