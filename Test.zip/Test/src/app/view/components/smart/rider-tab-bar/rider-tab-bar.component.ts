import {Component, OnInit, Input, Output, EventEmitter, OnChanges} from '@angular/core';
import { DragulaService } from 'ng2-dragula';

@Component({
  selector: 'rider-tab-bar',
  templateUrl: './rider-tab-bar.component.html',
  styleUrls: ['./rider-tab-bar.component.scss']
})
export class RiderTabBarComponent implements OnChanges, OnInit {


  private tabRestriction: number = 4;
  private horizontalRiderData: any = [];
  private verticalRiderData: any = [];
  private showVirticalRider: boolean = false;
  private riderCount: number;
  private riderSwap: any = {}


  @Output() riderRemoved = new EventEmitter();
  @Output() riderSelected = new EventEmitter();
  @Input() tabItems;

  private regiterIndex: any[] = [];

  constructor(private _dragulaService: DragulaService) { }

  ngOnInit() {
    this.initRider();
  }

  ngOnChanges(){
    this.initRider();
  }

  initRider() {
    let riderData = this.tabItems;
    this.riderCount = riderData.length;
    this.horizontalRiderData = riderData.slice(0, this.tabRestriction);
    this.verticalRiderData = riderData.slice(this.tabRestriction, riderData.length).reverse();
    let dragService = this._dragulaService;

    dragService.drag.subscribe((value) => {
      this.onDrag(value.slice(1));
    });
    dragService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }

  isVisible() {
    this.showVirticalRider = !this.showVirticalRider;
  }

  /**
   *
   * @param ev
   */
  removeRider(ev) {
    console.log('removeRider = ' + ev)
    if(this.tabItems.length > 1 && this.regiterIndex.indexOf(ev) === -1){
      const currentTab = this.tabItems[ev];
      this.riderRemoved.emit({
        type: currentTab.type,
        objref: currentTab.objref
      });

      this.tabItems.splice(ev, 1);
      this.initRider();
      this.regiterIndex.push(ev);
    }
  }

  selectRider(ev){
    const currentTab = this.tabItems[ev];
    console.log('selectRider = ' + ev)
    // this.riderSelected.emit({
    //   type: currentTab.type,
    //   objref: currentTab.objref
    // });
  }

  onDrag(args) {
    let [el, target, source] = args;
    this.riderSwap['dragIndex'] =  this.getTabIndex(el);
  }

  onDrop(args) {
    let [el, target, source] = args;
    this.riderSwap['dropIndex'] =  this.getTabIndex(el);
  }

  getTabIndex(el: any) {
    return [].slice.call(el.parentElement.children).indexOf(el);
  }
}
