import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { isNullOrUndefined } from "util";

@Component({
  selector: 'quick-search',
  templateUrl: 'quick-search.component.html',
  styleUrls: ['quick-search.component.scss']
})

export class QuickSearch implements OnChanges {

  private filterString;
  private filteredData;
  private dataCopy;

  @Output() onQuickSearch = new EventEmitter();
  @Input() data;


  ngOnChanges(){
    if(!this.dataCopy && this.data.length > 0){
      this.dataCopy = JSON.parse(JSON.stringify(this.data));
    }
  }

  quickSearch(data: Array<object>, searchtext: String): any {
    const st = searchtext.toLowerCase();

    if (isNullOrUndefined(st)) return data;

    return data.filter(obj => {
      let val;

      for (let property in obj) {
        val = obj[property];

        if (val === null) {
          continue;
        }
        if (val.toString().toLowerCase().includes(st)) {
          return true;
        }
      }
    });
  }

  onKeyUp() {
    this.filteredData = this.quickSearch((this.dataCopy)? this.dataCopy : this.data, this.filterString);
    this.onQuickSearch.emit(this.filteredData);
  }


  

}

