import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'index-tab-bar',
  templateUrl: './index-tab-bar.component.html',
  styleUrls: ['./index-tab-bar.component.scss']
})
export class IndexTabBarComponent implements OnInit {

  // Avaiable data for Index-Tab
  @Input() dataItems: object;


  @Output() tabClicked: EventEmitter<number> = new EventEmitter<number>();

  private currentTabIndex: number = 0;

  constructor() { }

  ngOnInit() { }

  /**
   * Tab Clicked on Index-Tab
   * @param index
   */
  onTabClick(index: number) {
    this.currentTabIndex = index;
    this.tabClicked.emit(index);
  }

}
