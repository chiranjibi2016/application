import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexTabBarComponent } from './index-tab-bar.component';

describe('IndexTabBarComponent', () => {
  let component: IndexTabBarComponent;
  let fixture: ComponentFixture<IndexTabBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexTabBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexTabBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
