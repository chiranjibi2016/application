import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'token-bar',
  templateUrl: './token-bar.component.html',
  styleUrls: ['./token-bar.component.scss']
})
export class TokenBarComponent implements OnInit {

  tokenItems = [
    {},
    {},
    {},
    {},
    {},
    {},
    {},
    {},
    {}
  ]

  constructor() { }

  ngOnInit() { }

}
