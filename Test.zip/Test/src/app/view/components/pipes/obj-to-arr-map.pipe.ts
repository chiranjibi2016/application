import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'objToArrMap'
})
export class ObjToArrMapPipe implements PipeTransform {

  transform(value: any, arg): any {

    let arry = [],
      i,
      len = value.length,
      prop;
    for (i = 0; i < len; i++) {
      let val = value[i];
      prop = val.col.trim().toLowerCase().replace(/\s/g, '')

      if (arg.hasOwnProperty(prop)) {

        if (val.datatype === "date") {
          arry.push(new Date(arg[prop]).toLocaleDateString());
        } else if (val.datatype === "currency") {
          arry.push("$" + arg[prop]);
        } else arry.push(arg[prop]);


      } else arry.push("")

    }
    return arry;
  }

}
