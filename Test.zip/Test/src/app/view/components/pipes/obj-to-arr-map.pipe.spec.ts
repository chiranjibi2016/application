import { ObjToArrMapPipe } from './obj-to-arr-map.pipe';

describe('ObjToArrMapPipe', () => {
  it('create an instance', () => {
    const pipe = new ObjToArrMapPipe();
    expect(pipe).toBeTruthy();
  });
});
