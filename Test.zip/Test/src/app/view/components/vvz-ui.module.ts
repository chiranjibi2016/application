import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragulaModule } from 'ng2-dragula';

import { HeaderBarComponent } from './smart/header-bar/header-bar.component';
import { MainMenuBarComponent } from './smart/main-menu-bar/main-menu-bar.component';
import { ActionBarComponent } from './smart/action-bar/action-bar.component';
import { RiderTabBarComponent } from './smart/rider-tab-bar/rider-tab-bar.component';
import { ActionItemComponent } from './dumb/action-item/action-item.component';
import { MenuItemComponent } from './dumb/menu-item/menu-item.component';
import { RiderTabItemComponent } from './dumb/rider-tab-item/rider-tab-item.component';
import { FlyinComponent } from './dumb/flyin/flyin.component';
import { ModalComponent } from './dumb/modal/modal.component';
import { LoaderComponent } from './dumb/loader/loader.component';
import { TitleComponent } from './dumb/title/title.component';
import { IndexTabBarComponent } from './smart/index-tab-bar/index-tab-bar.component';
import { IndexTabItemComponent } from './dumb/index-tab-item/index-tab-item.component';
import { BtnIconComponent } from './dumb/btn-icon/btn-icon.component';
import { BtnTextIconComponent } from './dumb/btn-text-icon/btn-text-icon.component';
import { ValidationNotificationComponent } from './dumb/validation-notification/validation-notification.component';
import { InlineNotificationComponent } from './dumb/inline-notification/inline-notification.component';
import { InputComponent } from './dumb/input/input.component';
import { TextAreaComponent } from './dumb/text-area/text-area.component';
import { DatePickerComponent } from './dumb/date-picker/date-picker.component';
import { RadioButtonComponent } from './dumb/radio-button/radio-button.component';
import { SelectBoxComponent } from './dumb/select-box/select-box.component';
import { DropDownComponent } from './dumb/drop-down/drop-down.component';
import { FilterDropdownComponent } from './dumb/filter-dropdown/filter-dropdown.component';
import { TokenBarComponent } from './smart/token-bar/token-bar.component';
import { TokenItemComponent } from './dumb/token-item/token-item.component';
import { RiderTabDropdownComponent } from './dumb/rider-tab-dropdown/rider-tab-dropdown.component';
import { OverviewTableComponent } from './dumb/overview-table/overview-table.component';
import { ObjToArrMapPipe } from './pipes/obj-to-arr-map.pipe';
import {QuickSearch} from "./smart/filter-bar/quick-search.component";
import { DateValueAccessorModule } from 'angular-date-value-accessor';

@NgModule({

  imports: [
    CommonModule,
    DragulaModule,
    FormsModule,
    DateValueAccessorModule,
    ReactiveFormsModule
  ],

  declarations: [
    HeaderBarComponent,
    MainMenuBarComponent,
    ActionBarComponent,
    RiderTabBarComponent,
    ActionItemComponent,
    MenuItemComponent,
    RiderTabItemComponent,
    FlyinComponent,
    ModalComponent,
    LoaderComponent,
    TitleComponent,
    IndexTabBarComponent,
    IndexTabItemComponent,
    BtnIconComponent,
    BtnTextIconComponent,
    ValidationNotificationComponent,
    InlineNotificationComponent,
    InputComponent,
    TextAreaComponent,
    DatePickerComponent,
    RadioButtonComponent,
    SelectBoxComponent,
    DropDownComponent,
    QuickSearch,
    FilterDropdownComponent,
    TokenBarComponent,
    TokenItemComponent,
    RiderTabDropdownComponent,
    OverviewTableComponent,
    ObjToArrMapPipe
  ],

  exports: [
    HeaderBarComponent,
    MainMenuBarComponent,
    ActionBarComponent,
    RiderTabBarComponent,
    ActionItemComponent,
    MenuItemComponent,
    RiderTabItemComponent,
    FlyinComponent,
    ModalComponent,
    LoaderComponent,
    TitleComponent,
    IndexTabBarComponent,
    IndexTabItemComponent,
    BtnIconComponent,
    BtnTextIconComponent,
    ValidationNotificationComponent,
    InlineNotificationComponent,
    InputComponent,
    TextAreaComponent,
    DatePickerComponent,
    RadioButtonComponent,
    SelectBoxComponent,
    DropDownComponent,
    QuickSearch,
    FilterDropdownComponent,
    TokenBarComponent,
    TokenItemComponent,
    RiderTabDropdownComponent,
    OverviewTableComponent
  ]

})
export class VvzUIModule { }
