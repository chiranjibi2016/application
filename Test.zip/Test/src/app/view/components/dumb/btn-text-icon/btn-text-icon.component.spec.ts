import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnTextIconComponent } from './btn-text-icon.component';

describe('BtnTextIconComponent', () => {
  let component: BtnTextIconComponent;
  let fixture: ComponentFixture<BtnTextIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtnTextIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnTextIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
