import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'btn-text-icon',
  templateUrl: './btn-text-icon.component.html',
  styleUrls: ['./btn-text-icon.component.scss']
})
export class BtnTextIconComponent implements OnInit {

  @Input() label: string;
  @Input() isIcon: boolean;
  @Input() isIconRight: boolean;
  @Input() icon: string;
  @Input() disabled: boolean;

  constructor() { }

  ngOnInit() { }

}
