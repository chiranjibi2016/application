import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'token-item',
  templateUrl: './token-item.component.html',
  styleUrls: ['./token-item.component.scss']
})
export class TokenItemComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
