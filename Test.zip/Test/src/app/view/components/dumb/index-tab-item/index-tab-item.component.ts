import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'index-tab-item',
  templateUrl: './index-tab-item.component.html',
  styleUrls: ['./index-tab-item.component.scss']
})
export class IndexTabItemComponent implements OnInit {

  /* Avaiable data for Index-Tab's 'label' & 'state' */
  @Input() label: string;
  @Input() disabled: boolean;
  @Input() selected: boolean;
  @Input() invalid: number;

  constructor() { }

  ngOnInit() { 

  }

}
