import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexTabItemComponent } from './index-tab-item.component';

describe('IndexTabItemComponent', () => {
  let component: IndexTabItemComponent;
  let fixture: ComponentFixture<IndexTabItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexTabItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexTabItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
