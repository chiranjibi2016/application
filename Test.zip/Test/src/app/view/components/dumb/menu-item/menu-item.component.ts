import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'menu-item',
  templateUrl: './menu-item.component.html',
  styleUrls: ['./menu-item.component.scss']
})
export class MenuItemComponent implements OnInit {

  @Input() icon: string;
  @Input() label: string;
  @Input() submenus: Array<any>;

  constructor(private router: Router) { }

  ngOnInit() { }


  onClickMenu() {
    this.router.navigate(['/home/', 'aocOverview'])
  }

}
