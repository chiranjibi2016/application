import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-down',
  templateUrl: './drop-down.component.html',
  styleUrls: ['./drop-down.component.scss']
})
export class DropDownComponent implements OnInit {

  private isVisible: boolean = false;
  private listVal: string = "Select";

  private listItems = [
    {
      label: "Option 1",
      value: "01"
    },
    {
      label: "Option 2",
      value: "02"
    },
    {
      label: "Option 3",
      value: "03"
    }

  ]

  constructor() { }

  ngOnInit() { }

  // Menu Toggle
  showMenu() {
    this.isVisible = (this.isVisible) ? false : true;
  }

  // List Value
  getValue(val){
    this.listVal = val;
  }

}
