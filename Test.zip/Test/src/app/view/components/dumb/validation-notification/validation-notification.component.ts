import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'validation-notification',
  templateUrl: './validation-notification.component.html',
  styleUrls: ['./validation-notification.component.scss']
})
export class ValidationNotificationComponent implements OnInit {

  @Input() valid: boolean;

  constructor() { }

  ngOnInit() { }

}
