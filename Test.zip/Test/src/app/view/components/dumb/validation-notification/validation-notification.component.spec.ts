import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationNotificationComponent } from './validation-notification.component';

describe('ValidationNotificationComponent', () => {
  let component: ValidationNotificationComponent;
  let fixture: ComponentFixture<ValidationNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidationNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidationNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
