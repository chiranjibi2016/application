import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'inline-notification',
  templateUrl: './inline-notification.component.html',
  styleUrls: ['./inline-notification.component.scss']
})
export class InlineNotificationComponent implements OnInit {

  @Input() message: string;

  constructor() { }

  ngOnInit() { }

}
