import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'action-item',
  templateUrl: './action-item.component.html',
  styleUrls: ['./action-item.component.scss']
})
export class ActionItemComponent implements OnInit {

  @Input() label: string;
  @Input() icon: string;
  @Input() state: boolean;

  @Output() onActionItemClick: EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit() { }

  //OnClick handle
  onClick(){
    this.onActionItemClick.emit(this.label.toLowerCase());
  }
}
