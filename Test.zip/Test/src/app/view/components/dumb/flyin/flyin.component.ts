import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'flyin',
  templateUrl: './flyin.component.html',
  styleUrls: ['./flyin.component.scss']
})
export class FlyinComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
