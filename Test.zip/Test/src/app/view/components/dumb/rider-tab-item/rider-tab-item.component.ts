import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'rider-tab-item',
  templateUrl: './rider-tab-item.component.html',
  styleUrls: ['./rider-tab-item.component.scss']
})
export class RiderTabItemComponent implements OnInit {

  @Input() icon: string;
  @Input() label: string;
  @Input() state: string;
  @Input() index: number;
  @Output() onRiderRemove = new EventEmitter();

  constructor() { }

  ngOnInit() {}

  close() {
    this.onRiderRemove.emit(this.index);
  }
}
