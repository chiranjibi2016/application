import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiderTabItemComponent } from './rider-tab-item.component';

describe('RiderTabItemComponent', () => {
  let component: RiderTabItemComponent;
  let fixture: ComponentFixture<RiderTabItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiderTabItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiderTabItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
