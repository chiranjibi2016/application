import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss']
})
export class DatePickerComponent implements OnInit {

  @Input() form: FormGroup;
  @Input() control: string;
  @Input() value: any;

  constructor() { }

  ngOnInit() {
   // console.log(this.value)
   }

}
