import { Component, OnInit, Input, Renderer, ElementRef, Output, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'overview-table',
  templateUrl: './overview-table.component.html',
  styleUrls: ['./overview-table.component.scss']
})
/**
 *
 */
export class OverviewTableComponent implements OnInit, OnChanges {

  @Input() colsmetaData: any[] = [];
  @Input() dataTable: any[] = [];

  @Output() onRowClick: EventEmitter<object> = new EventEmitter<object>();

  //table local state not related application state & not shared
  //with any other component
  private tableState: any = {
    sortMapColumn: [],
    lastSelectedColIndx: null,
    iconClasses: {
      ascend: 'fa-sort-asc',
      descend: 'fa-sort-desc',
      default: 'fa-sort'
    }
  }

  private minColWidth: any = [];

  // array of all items to be paged
  private allItems: any[];

  // pager object
  pager: any = {};

  // paged items
  pagedItems: any[];

  constructor(
    private renderer: Renderer,
    private el: ElementRef) {

  }

  ngOnChanges(){
    let map = this.tableState.sortMapColumn;
    if(map.length == 0 )
    this.colsmetaData.forEach(o => {
      map.push({ class: 'fa-sort', state: 'default' })
    })
  }
  ngOnInit() {
    //init table configuration code
    this.initTable();
  }

  /**
   * table configuration initiate
   */
  initTable() {
    let map = this.tableState.sortMapColumn;

    this.colsmetaData.forEach(o => {
      map.push({ class: 'fa-sort', state: 'default' });
      this.minColWidth.push(o.width);
    })

  }

  /**
   *
   * @param index is currently selected column index
   */
  columnHeaderClick(index) {

    let tableState = this.tableState,
      currentCol = tableState.sortMapColumn[index],
      lastColIndx = this.tableState.lastSelectedColIndx,
      iconClassObj = tableState.iconClasses,
      fieldName = this.colsmetaData[index].col.trim().toLowerCase().replace(/\s/g, '');

    currentCol.state = (currentCol.state === "default" || currentCol.state === "descend") ? "ascend" : 'descend';
    currentCol.class = iconClassObj[currentCol.state];

    if (lastColIndx !== null && lastColIndx !== index) {

      let prevCol = tableState.sortMapColumn[lastColIndx];
      prevCol.state = 'default';
      prevCol.class = iconClassObj[prevCol.state];
      tableState.lastSelectedColIndx = index;

    } else if (lastColIndx !== index) {
      tableState.lastSelectedColIndx = index;
    }

    //calling sort function
    this.sort(fieldName, currentCol.state, this.dataTable, index, this.colsmetaData)

  }

  /**
   *
   * @param fieldlName = column name
   * @param order = sorting order
   * @param dataTable = dataTable
   */
  sort(fieldName, order, dataTable, index, colsmetaData) {

    if (colsmetaData[index].datatype === 'number'
      || colsmetaData[index].datatype === 'currency'
      || colsmetaData[index].datatype === 'date') {

      dataTable.sort((a, b) => {
        return (order === 'ascend') ? (a[fieldName] - b[fieldName]) : -(a[fieldName] - b[fieldName]);
      })
    } else {

      dataTable.sort(function (a, b) {

        let fielValueA = a[fieldName].toLowerCase().trim().toLowerCase().replace(/\s/g, ''),
          fielValueB = b[fieldName].toLowerCase().trim().toLowerCase().replace(/\s/g, '');

        if (order === 'ascend') {
          if (fielValueA < fielValueB) //sort string ascending
            return -1
          else if (fielValueA > fielValueB)
            return 1
          else return 0 //default return value (no sorting)
        } else {
          if (fielValueA < fielValueB) //sort string descending
            return 1
          else if (fielValueA > fielValueB)
            return -1
          else return 0 //default return value (no sorting)
        }

      })

    }

  }

  /**
   *
   * @param ev
   */
  checkAll(ev) {
    this.dataTable.forEach(row => row.state = ev.target.checked)
  }

  /**
   *
   */
  isAllChecked() {
    return this.dataTable.every(row => row.state);
  }

  /**
   *
   * @param index
   * @param ev
   */
  rowSelect(index, ev) {
    this.dataTable[index].state = !this.dataTable[index].state;
    this.onRowClick.emit({index: index, selected: this.dataTable[index].state});
  }

  /**
   *
   * @param i = current row index
   * @param ev = event
   */
  toggleRowState(i, ev) {
    this.dataTable[i].state = !ev.target.checked;
  }

  onMouseDown(ev, i, colsmetaData, minColWidth) {

    let start = ev.target;
    let pressed: boolean = true;
    let startX = ev.x;
    let startWidth = colsmetaData[i].width;
    let col = colsmetaData[i];

    //called initResizableColumns
    this.initResizableColumns(start, pressed, startX, startWidth, col, i, minColWidth);

  }

  initResizableColumns(start, pressed, startX, startWidth, col, i, minColWidth) {
    this.renderer.listenGlobal('document', 'mousemove', (event) => {

      if (pressed) {

        let width = startWidth + (event.x - startX);
        col.width = (width > minColWidth[i]) ? width : minColWidth[i];

      }
    });
    this.renderer.listenGlobal('document', 'mouseup', (event) => {
      if (pressed) {
        pressed = false;
      }
    });
  }

}
