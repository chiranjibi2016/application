import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'module-title',
  templateUrl: './title.component.html',
  styleUrls: ['./title.component.scss']
})
export class TitleComponent implements OnInit {

  @Input() icon: String;
  @Input() title: String;

  constructor() { }

  ngOnInit() { }

}
