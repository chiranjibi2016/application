import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiderTabDropdownComponent } from './rider-tab-dropdown.component';

describe('RiderTabDropdownComponent', () => {
  let component: RiderTabDropdownComponent;
  let fixture: ComponentFixture<RiderTabDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiderTabDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiderTabDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
