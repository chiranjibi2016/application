import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'rider-tab-dropdown',
  templateUrl: './rider-tab-dropdown.component.html',
  styleUrls: ['./rider-tab-dropdown.component.scss']
})
export class RiderTabDropdownComponent implements OnInit {

  @Input() dataDropdownRider: any = [];
  @Input() totalRider: number;
  @Output() onRemoveTab = new EventEmitter();

  constructor() { }

  ngOnInit() { }

  close(index) {
    this.onRemoveTab.emit(this.totalRider - index);
  }


}
