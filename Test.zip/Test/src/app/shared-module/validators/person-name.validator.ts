import { FormControl } from '@angular/forms';

function personNameValidator(c: FormControl) {
  const minCharactersCount = 3;
  const separatorRegEx = /,| /;
  const words = c.value.split(separatorRegEx);
  const invalidWords = words.filter((word: string) => word !== '' && word.length < minCharactersCount);
  return invalidWords.length === 0 ? null : {
    personNameValidator: {
      valid: false
    }
  };
}

export default personNameValidator;
