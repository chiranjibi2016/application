import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'

import { CoreModule } from '../view/core/core.module';
import { BankingModule } from '../view/banking/banking.module';
import { HomeComponent } from '../view/core/home/home.component';
import { AocActions } from '../abstruct-actions/aoc-actions';
import { AocRestService } from '../rest-layer/aoc-rest.service';
import { StopPropogationDirective } from './directive/stop-propogation.directive';
import { NgReduxModule } from "@angular-redux/store";

@NgModule({

  imports: [
    CommonModule,
    CoreModule,
    NgReduxModule,
    HttpClientModule
  ],

  declarations: [

  StopPropogationDirective],

  providers: [
    AocActions,
    AocRestService
  ],

  exports: [
    HomeComponent
  ]

})

export class SharedModule { }
