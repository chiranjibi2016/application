import {SnakeToCamelPipe} from './snake-to-camel.pipe';

describe('SnakeToCamelPipe', () => {

  it('transforms not empty snake case string to camel case string', () => {
    const pipe = new SnakeToCamelPipe();
    const givenSnakeCaseString = 'natural-person';
    const expectedCamelCaseString = 'naturalPerson';
    expect(pipe.transform(givenSnakeCaseString)).toEqual(expectedCamelCaseString);
  });

  it('transforms multiple hyphens snake case string to camel case string', () => {
    const pipe = new SnakeToCamelPipe();
    const givenSnakeCaseString = 'non-natural-person';
    const expectedCamelCaseString = 'nonNaturalPerson';
    expect(pipe.transform(givenSnakeCaseString)).toEqual(expectedCamelCaseString);
  });

  it('does not transform empty string', () => {
    const pipe = new SnakeToCamelPipe();
    const givenSnakeCaseString = '';
    const expectedCamelCaseString = '';
    expect(pipe.transform(givenSnakeCaseString)).toEqual(expectedCamelCaseString);
  });

  it('does not transform null string', () => {
    const pipe = new SnakeToCamelPipe();
    const givenSnakeCaseString = null;
    const expectedCamelCaseString = null;
    expect(pipe.transform(givenSnakeCaseString)).toEqual(expectedCamelCaseString);
  });

  it('does not transform undefined string', () => {
    const pipe = new SnakeToCamelPipe();
    const givenSnakeCaseString = undefined;
    const expectedCamelCaseString = undefined;
    expect(pipe.transform(givenSnakeCaseString)).toEqual(expectedCamelCaseString);
  });
});
