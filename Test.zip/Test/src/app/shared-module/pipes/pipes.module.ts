import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SnakeToCamelPipe} from './snake-to-camel.pipe';
import {FormatDatePipe} from './format-date.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [
    SnakeToCamelPipe,
    FormatDatePipe,
  ],
  exports: [SnakeToCamelPipe, FormatDatePipe]
})
export class PipesModule {}
