import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'snakeToCamel'})
export class SnakeToCamelPipe implements PipeTransform {
  transform(snakeCaseString: string) {
    if (!snakeCaseString) {
      return snakeCaseString;
    }

    return snakeCaseString
              .replace(/-[a-z]/g, (match) =>  match.toUpperCase())
              .replace(/-/g, () => '');
  }
}
