import {Pipe, PipeTransform} from '@angular/core';
import * as moment from 'moment';

@Pipe({name: 'formatDate'})
export class FormatDatePipe implements PipeTransform {

  private format = 'DD.MM.YYYY';

  transform(date: string | Date) {
    if (!date) {
      return date;
    }
    return moment(date).format(this.format);
  }
}
