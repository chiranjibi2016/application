/**
 * All dynamic component constants.
 */
export class UiLebelContants {
    
        public static readonly NEW_BUTTON = 'Neu';
        public static readonly NEW_PAGE_TITLE = 'Neue';
        public static readonly SAVE = 'Speichern';
        public static readonly CLOSE = 'Schließen';
        public static readonly EDIT = 'Bearbeiten';
        public static readonly SUBMIT = 'Eintragen';
        public static readonly SEARCH = 'Suchen';
        public static readonly ALL_COLLAPSE = 'Alle Schließen';
    
    } 