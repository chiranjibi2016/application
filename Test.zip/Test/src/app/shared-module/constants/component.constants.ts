/**
 * All dynamic component constants.
 */
export class ComponentConstants {

    public static readonly AOC_OVERVIEW_TABLE = 'aocoverviewcomponent';
    public static readonly AOC_CREATE_EDIT_FORM = 'aocformcomponent';
    public static readonly AOC_DETAIL_VIEW = 'aocdetailcomponent';

} 