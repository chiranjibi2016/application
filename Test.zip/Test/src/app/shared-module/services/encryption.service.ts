import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Injectable()
export class EncryptionService {

  constructor() { }

  encrypt(content: string): string {
    return btoa(content);
  }

  decrypt(content: string): string {
    return atob(content);
  }

  checksum(content: string): string {
    return 'SHA-256:' + CryptoJS.SHA256(content);
  }
}
