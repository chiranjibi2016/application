import { ComponentConstants } from "../constants/component.constants";
import { AocOverviewComponent } from "../../view/aoc/aoc-overview/aoc-overview.component";
import { AocFormComponent } from "../../view/aoc/aoc-form/aoc-form.component";
import { AocDetailViewComponent } from "../../view/aoc/aoc-detail-view/aoc-detail-view.component";

export class DynamicComponentFactory {

    /**
     * This function is used to get the component class based on the type of component.
     * @param type 
     */
    public static getComponent(type: string): any {
        let component = null;
        switch (type) {
            case ComponentConstants.AOC_OVERVIEW_TABLE:
                component = AocOverviewComponent;
                break;
            case ComponentConstants.AOC_CREATE_EDIT_FORM:
                component = AocFormComponent;
                break;
            case ComponentConstants.AOC_DETAIL_VIEW:
                component = AocDetailViewComponent;
                break;
            default:
                console.log('No component available for  ' + type);
        }
        return component;
    }
} 