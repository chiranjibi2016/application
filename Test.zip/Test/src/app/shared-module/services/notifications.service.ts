import {Injectable} from '@angular/core';
import {WindowRefService} from './window-ref.service';

@Injectable()
export class NotificationsService {
  showDirectNotification: Function;

  constructor(private windowRef: WindowRefService) {
    const notificationsJsApi = this.windowRef.nativeWindow.xna
      .resources
      .find(resource => resource.type === 'jsApi' && resource.role.includes('notificationsEndpoint'))
      .fn();

    this.showDirectNotification = notificationsJsApi.showDirectNotification;
  }
}
