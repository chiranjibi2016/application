import {Injectable} from '@angular/core';
import {WindowRefService} from './window-ref.service';

@Injectable()
export class SettingsEndpoint {
  settingsUserProcessedGet: any;
  settingsUserSet: any;

  constructor(private windowRefServ: WindowRefService) {

    const settingsJsApi = this.windowRefServ.nativeWindow.xna
      .resources
      .find(resource => resource.type === 'jsApi' && resource.role.includes('settingsEndpoint'))
      .fn();

    this.settingsUserProcessedGet = settingsJsApi.settingsUserProcessedGet;
    this.settingsUserSet = settingsJsApi.settingsUserSet;
  }
}
