import {Injectable} from '@angular/core';

@Injectable()
export class TextsServ {
  textsFetch: any;

  constructor() {
    const textsJsApi = window['xna']
      .resources
      .find(resource => resource.type === 'jsApi' && resource.role.includes('textsEndpoint'))
      .fn();

    this.textsFetch = textsJsApi.textsFetch;
  }
}
