import {Injectable} from '@angular/core';
import {WindowRefService} from './window-ref.service';

@Injectable()
export class ElectronServ {
  private CALL_ID = 'x-xna-call-id';
  private X_XNA_STATUS = 'x-xna-status';
  private UNHANDLED_ERROR = 'Unhandled error';
  private intervalId: number;

  constructor(private windowRefServ: WindowRefService) {
  }

  logInfo(infoMessage: string) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('log', {
      logLevel: 'info',
      message: infoMessage
    });
  }

  logError(errorMessage: string) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('log', {
      logLevel: 'error',
      message: errorMessage
    });
  }

  logServerError(errorResp) {
    const errorMessage = {
      status: errorResp.status,
      xnaCallId: errorResp.headers.get(this.CALL_ID),
      xnaStatusHeader: errorResp.headers.get(this.X_XNA_STATUS) || this.UNHANDLED_ERROR
    };

    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('log', {
      logLevel: 'error',
      message: errorMessage
    });
  }

  startSpinner(id) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('spinnerOn', id);
    this.intervalId = this.windowRefServ.nativeWindow.setInterval(() => {
      this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('spinnerOn', id);
    }, 500);
  }

  stopSpinner(id) {
    this.windowRefServ.nativeWindow.clearInterval(this.intervalId);
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('spinnerOff', id);
  }

  headersGet() {
    return Object.assign({}, {
      Accept: 'application/json',
      'Content-Type': 'application/json'
    }, this.windowRefServ.nativeWindow.xna.getAjaxHeaders());
  }

  moduleCloseForAutoSignOut() {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('autoSignOut');
  }

  moduleCloseForSignOut() {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('signOut');
  }

  moduleCloseForExit() {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('exit');
  }

  moduleClose(data?: any) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('killMe', {data});
  }

  sendMessage(message: string, data?: any) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost(message, data);
  }

  listenForMessage(message: string, listener: Function) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.on(message, listener);
  }

  openModule(tab: {url: string, label: string}) {
    this.windowRefServ.nativeWindow.xna.electronIpcRenderer.sendToHost('openTab', tab);
  }

  userIdGet() {
    return this.windowRefServ.nativeWindow.xna.userData.user.id;
  }

  organizationIdGet() {
    return this.windowRefServ.nativeWindow.xna.userData.organization.id;
  }
}
