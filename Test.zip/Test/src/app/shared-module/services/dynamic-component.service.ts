import { Injectable, ViewContainerRef } from '@angular/core';
import { ComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';
import { DynamicComponentFactory } from './dynamic-component.factory';

@Injectable()
export class DynamicComponentService {

  // Keep track of list of generated components for removal purposes
  dynamicComponents: Object = {};

  constructor(
    private _viewContainerRef: ViewContainerRef,
    private _componentFactoryResolver: ComponentFactoryResolver
  ) {

  }

  /**
   * This function is used to create a component dynamically based on the selected option by user. 
   * @param searchCriteriaGuiTO 
   */
  private addComponent(componentName: string, componentContainer: ViewContainerRef): void {

    // Create component dynamically inside the ng-template
    const componentFactory = this._componentFactoryResolver.resolveComponentFactory(DynamicComponentFactory.getComponent(componentName));

    const component: any = componentContainer.createComponent(componentFactory);
    //component.instance.searchCriteriaGui = searchCriteriaGuiTO;

    // Push the component so that we can keep track of which components are created
    // this.components.set(searchCriteriaGuiTO.id, component);
  }

}
