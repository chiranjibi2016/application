import {Injectable} from '@angular/core';

@Injectable()
export class PermissionsProvider {

  permissionsCurrentGet: any;
  usersGet: any;

  constructor() {
    const permissionsJsApi = window['xna']
      .resources
      .find(resource => resource.type === 'jsApi' && resource.role.includes('permissionsEndpoint'))
      .fn();

    this.permissionsCurrentGet = permissionsJsApi.permissionsCurrentGet;
    this.usersGet = permissionsJsApi.usersGet;
  }
}
