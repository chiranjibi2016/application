import {Injectable} from '@angular/core';

@Injectable()
export class ImmutableHelperServ {
  addItemInsideArray: any;
  updateItemInsideArray: any;

  static addItemInsideArray(item: any, items: any[], index: number): any[] {
    if (index === -1) {
      return items;
    }
    return items
      .slice(0, index + 1)
      .concat(item)
      .concat(items.slice(index + 1));
  }

  static updateItemInsideArray(arr, item, index): any[] {
    if (index >= 0) {
      return arr
        .slice(0, index)
        .concat(item)
        .concat(arr.slice(index + 1));
    }
    return arr;
  }

  constructor() {
    this.addItemInsideArray = ImmutableHelperServ.addItemInsideArray;
    this.updateItemInsideArray = ImmutableHelperServ.updateItemInsideArray;
  }
}
