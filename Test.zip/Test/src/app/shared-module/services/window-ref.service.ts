declare global { // global augmentation of Window type to add missing property
  interface Window {
    xna: {
      resources: any,
      electronIpcRenderer: any,
      windowHelpersAdded: any,
      getAjaxHeaders: any,
      userData: any
    };
  }
}

import { Injectable } from '@angular/core';

function getWindow (): Window {
  return window;
}

@Injectable()
export class WindowRefService {
  get nativeWindow (): Window {
    return getWindow();
  }
}
