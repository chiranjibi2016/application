import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { VvzMainComponent } from './vvz-main.component';
import { EncryptionService } from "./shared-module/services/encryption.service";
import { VvzRoutingModule } from './vvz-routing.module';
import { SharedModule } from './shared-module/shared.module';

@NgModule({

  declarations: [
    VvzMainComponent
  ],

  imports: [
    BrowserModule,
    VvzRoutingModule,
    SharedModule
  ],

  providers: [
    EncryptionService
  ],

  bootstrap: [VvzMainComponent]
  
})

export class AppModule { }
