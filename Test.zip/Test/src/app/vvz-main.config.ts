export const vvzMainConfig = {
    vvzModuleMockUrl: 'http://localhost:3000/',
    vvzModuleUrl: ''
};
