import { Component } from '@angular/core';

@Component({
  selector: 'vvz-root',
  template: '<router-outlet></router-outlet>'
})
export class VvzMainComponent {

  constructor() {
  }

}
