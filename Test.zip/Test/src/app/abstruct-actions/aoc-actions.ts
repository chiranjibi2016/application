import { Injectable } from "@angular/core";
import { AocRestService } from "../rest-layer/aoc-rest.service";

@Injectable()
export class AocActions{

    constructor(
        private _aocRest: AocRestService
    ){

    }

    loadAllAocData = () => {
        return this._aocRest.getAllAocs();
    }

    loadAocClolumnMetaData = () => {
        return [
            { "col": "selected", "width": 150, "datatype": "string" },
            { "col": "SlNo", "width": 150, "datatype": "number" },
            { "col": "id", "width": 150, "datatype": "number" },
            { "col": "revision", "width": 150, "datatype": "date" },
            { "col": "art", "width": 150, "datatype": "currency" },
            { "col": "verwNr", "width": 150, "datatype": "no" },
            { "col": "uvzUrNr", "width": 150, "datatype": "no" }
        ];
    }

}
