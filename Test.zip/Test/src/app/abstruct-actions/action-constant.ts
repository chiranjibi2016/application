export const AocConstant = {
    GETALLAOC : 'getAllAoc'
}