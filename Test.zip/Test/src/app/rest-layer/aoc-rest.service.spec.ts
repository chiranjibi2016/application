import { TestBed, inject } from '@angular/core/testing';

import { AocRestService } from './aoc-rest.service';

describe('AocRestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AocRestService]
    });
  });

  it('should be created', inject([AocRestService], (service: AocRestService) => {
    expect(service).toBeTruthy();
  }));
});
