import { TestBed, inject } from '@angular/core/testing';

import { BankingRestService } from './banking-rest.service';

describe('BankingRestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BankingRestService]
    });
  });

  it('should be created', inject([BankingRestService], (service: BankingRestService) => {
    expect(service).toBeTruthy();
  }));
});
