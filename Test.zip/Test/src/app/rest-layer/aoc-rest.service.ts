import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {environment} from "../../environments/environment";

@Injectable()
export class AocRestService {

  constructor(
    private _http: HttpClient
  ) {

  }

  getAllAocs(){
    return  this._http.get(environment.restBaseUrl + environment.getAllAoCURL);
  }

}
