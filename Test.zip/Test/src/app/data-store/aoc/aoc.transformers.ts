import { List, Map } from 'immutable';
import {IAoc, IAocs, AocRecord} from './model/aoc.model';

export function deimmutifyAoc(state: IAocs): Object[] {
  return state.toJS();
}

export function reimmutifyAoc(plain): IAocs {
  return List<IAoc>(plain ? plain.map(AocRecord) : []);
}
