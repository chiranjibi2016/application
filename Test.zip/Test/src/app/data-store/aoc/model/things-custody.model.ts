import { List, Record } from 'immutable';

export interface IThingCustody {
  id: any,
  modificationCounter: number,
  revision: any,
  beschreibung: string
  nennSchatzwert: number,
  currency: string
}

export type IThingCustodies = List<IThingCustody>;

export class thingcustody{
  constructor(
    public id: any,
    public modificationCounter: number,
    public revision: any,
    public isOnlineBanking: boolean,
    public kontotyp: any,
    public kreditinstitut: string,
    public iban: string,
    public bic: string,
    public saldo: number
  ){

  }
}
