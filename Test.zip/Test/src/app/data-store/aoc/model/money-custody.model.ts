import { List } from 'immutable';

export interface IMoneyCustody {
  id: any,
  modificationCounter: number,
  revision: any,
  isOnlineBanking: boolean,
  kontotyp: any,
  kreditinstitut: string,
  iban: string,
  bic: string,
  saldo: number,
  wahrung: string
}

export type IMoneyCustodies = List<IMoneyCustody>;

export class moneycustody{
  constructor(
    public id: any,
    public modificationCounter: number,
    public revision: any,
    public isOnlineBanking: boolean,
    public kontotyp: any,
    public kreditinstitut: string,
    public iban: string,
    public bic: string,
    public saldo: number,
    public wahrung: string
  ){

  }
}
