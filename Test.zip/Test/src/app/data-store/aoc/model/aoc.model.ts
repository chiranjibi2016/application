import { List, Record, Map } from 'immutable';
import {ICustody, custody} from "./custody.model";

export interface IAoc {
  selected?: boolean,
  SlNo?: number,
  id?: any,
  modificationCounter?: number,
  revision?: any,
  art?: string,
  verwNr?: any,
  uvzUrNr?: string,
  bezeichnung?: string,
  status?: string,
  bearbeiter: string,
  zuletztBearbeitet: string,
  saldoBestand: number,
  wahrung: string,
  custody?: ICustody
}

export type IAocs = List<IAoc>;

export const AocRecord = Record({
  id: 0,
  numberOfSeats: 0,
  status: '',
  order: Map<number, number>()
});

export class Aoc{
  constructor(
    public selected?: boolean,
    public SlNo?: number,
    public id?: any,
    public modificationCounter?: number,
    public revision?: any,
    public art?: string,
    public verwNr?: any,
    public uvzUrNr?: string,
    public bezeichnung?: string,
    public status?: string,
    public bearbeiter?: string,
    public zuletztBearbeitet?: string,
    public saldoBestand?: number,
    public wahrung?: string,
    public custody?: ICustody
  ){
  }
}
