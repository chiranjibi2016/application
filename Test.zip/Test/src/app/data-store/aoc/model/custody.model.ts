import { List, Record } from 'immutable';
import { IThingCustody, IThingCustodies, thingcustody} from "./things-custody.model";
import { IMoneyCustody, IMoneyCustodies} from "./money-custody.model";

export interface ICustody {
  id: any,
  modificationCounter: number,
  revision: any,
  moneycustody?: IMoneyCustodies,
  thingcustody?: IThingCustodies
}

export class custody{
  constructor(
    public id: any,
    public modificationCounter: number,
    public revision: any,
    public moneycustody: IMoneyCustodies,
    public thingcustody: IThingCustodies
  ){

  }
}
