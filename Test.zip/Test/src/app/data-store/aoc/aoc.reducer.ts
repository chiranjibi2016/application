import { List, Record, fromJS } from 'immutable';
import { IAoc, IAocs, AocRecord } from './model/aoc.model';
import { INITIAL_STATE } from './aoc.initial-state';

// import {
//   PARTY_JOINED,
//   PARTY_LEFT,
//   PARTY_SEATED
// } from '../../../global-constant';

export function aocReducer(state: IAocs = INITIAL_STATE, action): IAocs {
  // switch (action.type) {
  //   case PARTY_JOINED: return state.push(action.payload);
  //   case PARTY_LEFT: return state
  //     .filter(n => n.partyId !== action.payload.partyId) as IAocs;
  //   case PARTY_SEATED: return state
  //     .filter(n => n.partyId !== action.payload.partyId) as IAocs;
  //   default: return state;
  // }
  return state;
};
