import { List } from 'immutable';
import { IAoc } from './model/aoc.model';

export const INITIAL_STATE = List<IAoc>();
