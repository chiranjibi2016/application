import { List } from "immutable";

export interface IAocNewViewState{
  id: any,
  label: string,
  state: string
}

export type IAocNewViewStates = List<IAocNewViewState>;
