import { IAocViewState } from "./aoc-view-state.model";

export interface IViewState {
  aoc: IAocViewState
}

// export const ViewStateRecord = Record({
//   aoc: {}
// });
