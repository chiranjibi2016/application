import { List } from "immutable";

export interface IAocEditViewState{
  id: any,
  label: string,
  state: string
}

export type IAocEditViewStates = List<IAocEditViewState>;
