import { IAocNewViewStates } from "./aoc-new-view-state.model";
import { IAocEditViewStates } from "./aoc-edit-view-state.model";

export interface IAocViewState{
  id: any,
  label: string,
  state: string,
  new: IAocNewViewStates,
  edit: IAocEditViewStates,
  overview: any,
  selectedAoc: any
}
