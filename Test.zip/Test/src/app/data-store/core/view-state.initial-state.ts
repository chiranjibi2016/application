import {List, Map} from 'immutable';

export const INITIAL_STATE = Map<string, any>();
