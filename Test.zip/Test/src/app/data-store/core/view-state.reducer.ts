import { List, Record, fromJS } from 'immutable';
import { INITIAL_STATE } from './view-state.initial-state';
import { IAocViewState } from "./model/aoc-view-state.model";
import { IViewState } from "./model/view-state.model";

// import {
//   PARTY_JOINED,
//   PARTY_LEFT,
//   PARTY_SEATED
// } from '../../../global-constant';

export function viewStateReducer(state: IViewState, action): IViewState {
  // switch (action.type) {
  //   case PARTY_JOINED: return state.push(action.payload);
  //   case PARTY_LEFT: return state
  //     .filter(n => n.partyId !== action.payload.partyId) as IAocs;
  //   case PARTY_SEATED: return state
  //     .filter(n => n.partyId !== action.payload.partyId) as IAocs;
  //   default: return state;
  // }
  return state;
};
