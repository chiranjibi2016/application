import { combineReducers } from 'redux';

import * as aoc from './aoc/index'
import * as view from './core/index'

/*
 * This is where we 'assemble' the full store out of its models.
 */

export interface IAppState {
  // Node for all loaded AoC objecta
  aocs?: aoc.IAocs;
  // Node for maintaining all dynamin compoent
  // instantiation, remove & manage rider-bar creation clicks
  view_state?: view.IViewState;
};

export const rootReducer = combineReducers<IAppState>({
  aoc: aoc.aocReducer
});

export function deimmutify(state: IAppState): Object {
  return {
    aocs: aoc.deimmutifyAoc(state.aocs)
  };
}

export function reimmutify(plain): IAppState {
  return plain ? {
    aocs: aoc.reimmutifyAoc(plain.aocs)
  } : {};
}
