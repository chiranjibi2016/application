/*jshint strict:false */

var request = require("request");
var express = require("express");

var app = express();
var getAoC = require("./responses/transaction-data.json");
var createAoC = require("./responses/transaction-data.json");
var updateAoC = require("./responses/transaction-data.json");
var searchAoC = require("./responses/transaction-data.json");

app.get("/hello", function (req, res) {
    res.send("Hello Express!");
});

app.get("/vvz/aoc-service/app/aoc/getallaoc", reply(getAoC));
app.post("/vvz/aoc-service/app/aoc/submitaoc", reply(createAoC));
app.put("/vvz/aoc-service/app/aoc/updateaoc", reply(updateAoC));
app.put("/vvz/aoc-service/app/aoc/savedraftaoc", reply(saveAoC));
app.get("/vvz/search-aoc-service/app/search/search", reply(searchAoC));

function reply(json) {
    return function(req, res) { return res.status(200).jsonp(json); }
}

app.listen(3000, function () {
    console.log("Example app listening on port 3000!");
});
