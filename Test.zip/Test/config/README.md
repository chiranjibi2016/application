cd xna-demo-web
npm i
npm run build
npm run xnapublish

Artefakt: my.company.xna.demo:demo-web:1.0.0-SNAPSHOT
