const path = require('path');
const isProd = (process.env.NODE_ENV === 'production');
const WrapperPlugin = require('wrapper-webpack-plugin');
const GenerateJsonPlugin = require('generate-json-webpack-plugin');

module.exports = {
  entry: path.join(__dirname, '..', 'src', 'endpoint', 'index.js'),
  output: {
    filename: 'index.js',
    path: path.join(__dirname, '..', 'dist', 'endpoint')
  },
  context: __dirname,
  target: 'web',
  devtool: !isProd && 'source-map',
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel-loader'
      }
    ]
  },
  plugins: [
    new WrapperPlugin({ // this pulls out the default export from the index.js bundle
      test: /\.js$/,
      header: '(() => {\nreturn',
      footer: '\n})().default'
    }),
    new GenerateJsonPlugin('../module.json', (() => {
      const moduleJson = require('../src/module.json');
      const jsApiMethods = [
        'getPerson',
        'searchPersons'
      ];
      const jsApiJsDocCommentsObject = require('jsdoc-api').explainSync({ files: './src/endpoint/*' })
        .filter(_ => _.comment)
        .reduce((acc, _) => ((jsApiMethods.indexOf(_.name) > -1 && (acc[_.name] = _.description)), acc ), {});
      moduleJson.resources
        .find(_ => _.role.includes('personsEndpoint'))
        .documentationSummary = jsApiJsDocCommentsObject;
      return moduleJson;
    })(), undefined, 2)
  ]
};
